from django.shortcuts import render
from rest_framework import viewsets, permissions, status
from rest_framework.decorators import action
from rest_framework.response import Response
from django.db.models import Sum
from .models import Cliente, Producto, Venta, DetalleVenta
from .serializers import (
    ClienteSerializer, ProductoSerializer, VentaSerializer, 
    DetalleVentaSerializer, UserSerializer
)
from django.contrib.auth.models import User

# Create your views here.

class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [permissions.IsAdminUser]

class ClienteViewSet(viewsets.ModelViewSet):
    queryset = Cliente.objects.all()
    serializer_class = ClienteSerializer
    permission_classes = [permissions.IsAuthenticated]

    @action(detail=True, methods=['get'])
    def ventas(self, request, pk=None):
        cliente = self.get_object()
        ventas = cliente.ventas.all()
        serializer = VentaSerializer(ventas, many=True)
        return Response(serializer.data)

class ProductoViewSet(viewsets.ModelViewSet):
    queryset = Producto.objects.all()
    serializer_class = ProductoSerializer
    permission_classes = [permissions.IsAuthenticated]

    @action(detail=True, methods=['post'])
    def ajustar_stock(self, request, pk=None):
        producto = self.get_object()
        cantidad = int(request.data.get('cantidad', 0))
        
        if not cantidad:
            return Response(
                {'error': 'Debe especificar una cantidad'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        producto.stock += cantidad
        producto.save()
        
        return Response({
            'mensaje': f'Stock ajustado. Nuevo stock: {producto.stock}',
            'stock': producto.stock
        })

class VentaViewSet(viewsets.ModelViewSet):
    queryset = Venta.objects.all()
    serializer_class = VentaSerializer
    permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(vendedor=self.request.user)

    @action(detail=True, methods=['post'])
    def cambiar_estado(self, request, pk=None):
        venta = self.get_object()
        nuevo_estado = request.data.get('estado')
        
        if nuevo_estado not in dict(Venta.ESTADO_CHOICES):
            return Response(
                {'error': 'Estado no válido'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        venta.estado = nuevo_estado
        venta.save()
        
        return Response({
            'mensaje': f'Estado actualizado a: {nuevo_estado}',
            'estado': nuevo_estado
        })

class DetalleVentaViewSet(viewsets.ModelViewSet):
    queryset = DetalleVenta.objects.all()
    serializer_class = DetalleVentaSerializer
    permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):
        detalle = serializer.save()
        venta = detalle.venta
        
        # Actualizar el total de la venta
        total = venta.detalles.aggregate(
            total=Sum('subtotal')
        )['total'] or 0
        
        venta.total = total
        venta.save()
        
        # Actualizar el stock del producto
        producto = detalle.producto
        producto.stock -= detalle.cantidad
        producto.save()

def mapa_ventas(request):
    return render(request, 'mapa_ventas.html')
