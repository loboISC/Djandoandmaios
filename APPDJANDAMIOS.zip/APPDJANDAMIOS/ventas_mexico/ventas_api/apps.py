from django.apps import AppConfig


class VentasApiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ventas_api'
