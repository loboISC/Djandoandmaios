
from django.db import models

class VentaEstado(models.Model):
    estado = models.CharField(max_length=100, unique=True)
    porcentaje_ventas = models.FloatField()

    def __str__(self):
        return self.estado

