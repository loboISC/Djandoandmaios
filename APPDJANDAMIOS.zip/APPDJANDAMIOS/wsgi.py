import os
import sys

# Agregar el directorio del proyecto al path
path = '/home/TU_USUARIO_PYTHONANYWHERE/APPDJANDAMIOS'
if path not in sys.path:
    sys.path.append(path)

# Configurar las variables de entorno
os.environ['DJANGO_SETTINGS_MODULE'] = 'APPDJANDAMIOS.settings'

# Importar la aplicación Django
from django.core.wsgi import get_wsgi_application
application = get_wsgi_application() 